import { State, StateStoreError } from "alchemy/State";
import { BucketObjects } from "alchemy/State/BucketState";
import * as Effect from "effect/Effect";
import * as HttpClient from "effect/http/HttpClient";
import * as Layer from "effect/Layer";
import * as Redacted from "effect/Redacted";
import * as Scope from "effect/Scope";
//#region src/github-state/GitHubState.d.ts
/**
 * An Alchemy state store on a branch of a GitHub repository.
 *
 * Built on Alchemy's BucketState, like the S3 and Cloud Storage stores. The "bucket" is one Git
 * branch: a key is a path, an object's version is its blob sha. Writes queue up and one worker
 * turns everything queued into one commit through the Git Data API; the ref update with
 * `force: false` is the compare-and-swap, and a lost race starts the batch again on the new head.
 *
 * The lease (`__lease__.json`) lives on a second branch, `<branch>-lock`, so the state branch holds
 * only state.
 */
export interface GitHubStateOptions {
  /** `owner/name`. @default GITHUB_REPOSITORY, else the `origin` remote */
  readonly repository?: string;
  /** @default "alchemy-state-store" */
  readonly branch?: string;
  /** Base64 of 32 bytes that seals each secret. @default ALCHEMY_GITHUB_STATE_KEY */
  readonly key?: Redacted.Redacted<string>;
}
/** The BucketObjects of one branch (plus its `-lock` branch), bound to the ambient scope. */
export declare const makeGitHubObjects: (options?: GitHubStateOptions) => Effect.Effect<BucketObjects, StateStoreError, HttpClient.HttpClient | Scope.Scope>;
/**
 * The State layer. It reads the key and builds the store on the first state operation, bound to
 * this layer's scope, so a missing key fails the run before any read or write.
 *
 * A `get` or `getOutput` of a stage that the run has not locked takes no lock. So a preview that
 * reads a resource of `prod` runs beside a deploy of `prod`; with the lock, one of them failed.
 * Every other call takes the lock of its stage, as BucketState does. A run gives the first answer
 * of such a read again, and when it later locks that stage, it fails if those files changed.
 */
export declare const state: (options?: GitHubStateOptions) => Layer.Layer<State, never, HttpClient.HttpClient>;
//#endregion
//# sourceMappingURL=github-state.d.ts.map