import { State } from "alchemy/State";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Schema from "effect/Schema";
//#region src/run-record/RunRecord.d.ts
/** The key of the record in the stage output document. */
export declare const RUN_RECORD_KEY = "samebase.run";
/** The name of the stack file. Alchemy resolves `--config` against the working directory and does not expose it to a state layer, so the record assumes the default name. */
export declare const STACK_FILE_NAME = "alchemy.run.ts";
/** Version 1 of the record. A reader validates `version` first. */
export interface RunRecord {
  readonly version: 1;
  /** GitHub `owner/name`. */
  readonly repository: string;
  /** Path of the stack file from the repository root, POSIX separators, such as `apps/samebase/alchemy.run.ts`. */
  readonly stackFile: string;
  /** The branch that was deployed: the head branch of a pull request, else the pushed branch. */
  readonly branch: string;
  /** The pull request whose head was deployed, or null for a push and for a checkout. */
  readonly pullRequest: number | null;
  /** The commit that was deployed: the head of the pull request, else GITHUB_SHA, else git HEAD. */
  readonly headCommit: string;
  /** The GitHub Actions run and attempt, or null for a checkout. */
  readonly runUrl: string | null;
  /**
   * Where the record came from: the variables of a GitHub Actions run, or git in a checkout outside
   * GitHub Actions, such as a developer's machine, a sandbox, or another CI. It says nothing of the
   * stage: a checkout can deploy `prod`.
   */
  readonly source: "github-actions" | "checkout";
  /** ISO 8601, when the record was written. */
  readonly recordedAt: string;
}
declare const RunRecordError_base: Schema.Class<RunRecordError, Schema.TaggedStruct<"RunRecordError", {
  readonly reason: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class RunRecordError extends RunRecordError_base {
  get message(): string;
}
/** Where the run happens: the working directory of the stack and the process environment. */
export interface RunEnvironment {
  readonly cwd: string;
  readonly env: Readonly<Record<string, string | undefined>>;
}
/**
 * The record of this run: from the GitHub Actions variables and the event
 * payload when GITHUB_ACTIONS is `true`, else from git in `cwd`, which needs
 * a branch and an `origin` remote with `owner/name`. Fails when a value is
 * missing; nothing is guessed.
 */
export declare const runRecord: (where: RunEnvironment) => Effect.Effect<RunRecord, RunRecordError>;
/**
 * The output document of a stage: the stack's output plus the record under
 * {@link RUN_RECORD_KEY}, or undefined for an output with no place for the
 * key: a string, an array, null, or an object that is not plain, such as a
 * Date. A value that the stack itself put under the key stays.
 */
export declare const outputWithRunRecord: (output: unknown, record: RunRecord) => object | undefined;
/**
 * The state of `inner`, with the record of this run in each stage output that it writes, under
 * {@link RUN_RECORD_KEY}: `state: withRunRecord(Convex.state())`, or the same over another state
 * layer, such as the Cloudflare state store of Alchemy. Every other call goes to `inner` as it is.
 *
 * The record is derived once, at the first use of the state, and `recordedAt` is the time of the
 * output write. A checkout that gives no record, such as a tarball without git, a checkout without
 * `origin`, or a detached HEAD, still reads, plans, and destroys: its outputs are written without
 * the record, and the log says why. The engine writes the output only after a full successful
 * apply, so the record names the last full successful deploy of the stage.
 */
export declare const withRunRecord: <E, R>(inner: Layer.Layer<State, E, R>) => Layer.Layer<State, E, R>;
//#endregion
export {};
//# sourceMappingURL=run-record.d.ts.map